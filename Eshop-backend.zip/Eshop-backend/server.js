const express = require('express');
const cors = require('cors');
const app = express();
require('./connection');
//const http = require('http');
//const server = http.createServer(app);
//const {Server} = require('socket.io');
//const io = new Server(server, {
   // cors: 'http://localhost:3000',
    //methods:['GET', 'POST', 'PATCH', "DELETE"]
//})
//const User = require('./models/user.model');

const userRoutes = require('./routes/user.route');
const productRoutes = require('./routes/product.route');
const orderRoutes = require('./routes/order.route');
const imageRoutes = require('./routes/image.route');

app.use(cors());
app.use(express.urlencoded({extended: true}));
app.use(express.json());
app.use('/users', userRoutes);
app.use('/products', productRoutes);
app.use('/orders', orderRoutes);
app.use('/images', imageRoutes);

const port = 9000;
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

//app.set('socketio', io);